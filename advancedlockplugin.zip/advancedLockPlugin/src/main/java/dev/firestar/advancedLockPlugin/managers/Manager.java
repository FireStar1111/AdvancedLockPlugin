package dev.firestar.advancedLockPlugin.managers;

public interface Manager {

    void registerManagers();
    void registerUtils();
    void registerCommands();
    void registerListeners();
    void registerClasses();

}
